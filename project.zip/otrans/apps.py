from django.apps import AppConfig


class OtransConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'otrans'
    verbose_name = 'Other Transactions'
